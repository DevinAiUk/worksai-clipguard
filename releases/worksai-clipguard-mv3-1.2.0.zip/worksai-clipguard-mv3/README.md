# WorksAi ClipGuard MV3 Extension (v1.2.0)

Unzip and load unpacked in `chrome://extensions` with Developer Mode enabled.
